// Al Igual que los objetos un arreglo se puede modificar a pesar ade utilizar la palabra const

const meses = ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio'];

meses[0] = 'Nuevo Mes'


// También se puede añadir al final
meses[6] = 'Ultimo Mes'

// Al igual que los objetos en los arrays existen métodos que son bastante útiles, así que veamos algunos ejemplos en los siguientes videos.

console.log(meses);