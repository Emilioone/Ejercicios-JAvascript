// Veamos como utilizar los operadores de mayor que o menor que...


let dinero = 500;
let totalCarrito = 300;

if( dinero > totalCarrito ) {
    console.log('Pago Correcto');
} else {
    console.log('Fondos Insuficientes');
}

// También puede ser sin llaves
let dinero = 500;
let totalCarrito = 300;

if( dinero > totalCarrito )
    console.log('Pago Correcto');
else
    console.log('Fondos Insuficientes');
